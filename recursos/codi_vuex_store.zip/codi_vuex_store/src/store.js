// src/store/index.js (o store.js si és un arxiu únic)
import { createStore } from 'vuex';

const store = createStore({
  state() {
    return {
      counter: 5
    };
  },
  mutations: {
    ADD_PERSON(state) {
      state.counter++;
    },
    DELETE_PERSON(state) {
      state.counter--;
    }
  }
});

export default store;
