// src/main.js
import { createApp } from 'vue';
import App from './App.vue';
import store from './store'; // Importa el teu store

createApp(App)
  .use(store)  // Afegeix Vuex al teu app
  .mount('#app');
