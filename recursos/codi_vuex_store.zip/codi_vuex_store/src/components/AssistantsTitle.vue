<template>
  <h1>Assistents a la reunió en directe</h1>
</template>

<script>
export default {

}
</script>