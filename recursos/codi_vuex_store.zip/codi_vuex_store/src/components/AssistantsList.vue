<template>

    <div>
        <ul v-for="person in peopleList" :key="person">
            <li>{{person}}</li>
        </ul>
        <div>
            <button @click="addAssistant()">Afegir Assistent</button>
            <button @click="deleteAssistant()">Eliminar Assistent</button>
        </div>    
    </div>
    
</template>

<script>
export default {

    data: function (){
        return{
            peopleList:['Ana', 'Xuso', 'Pepe', 'Evaristo', 'Aitana'],
        }
    },
    methods: {
        addAssistant: function(){
            var randomNumber = Math.floor(Math.random() * 10001);
            this.peopleList.push(`Assistent${randomNumber}`);
            this.$store.commit("ADD_PERSON");
        },
        deleteAssistant: function(){
            this.peopleList.splice(0,1);
            this.$store.commit("DELETE_PERSON");
        }
    }

}
</script>

